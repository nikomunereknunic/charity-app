// database.js
// Vytvoří (pokud neexistuje) SQLite databázi se dvěma tabulkami:
//  - needs: jednotlivé potřeby/sbírky, na které lze přispívat
//  - invoices: jednotlivé Lightning platby a jejich stav

const sqlite3 = require('sqlite3').verbose();
const DBSOURCE = "charity.db";

const db = new sqlite3.Database(DBSOURCE, (err) => {
    if (err) {
        console.error(err.message);
        throw err;
    }

    console.log('Připojeno k SQLite databázi (' + DBSOURCE + ').');

    db.run(`
        CREATE TABLE IF NOT EXISTS needs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            target_amount INTEGER NOT NULL,
            current_amount INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'open'
        )
    `, (err) => {
        if (err) console.error("Chyba při vytváření tabulky 'needs':", err.message);
    });

    // Tabulka pro sledování jednotlivých plateb — v původním návrhu chyběla,
    // ale server.js do ní zapisuje, takže je nutná pro funkčnost.
    db.run(`
        CREATE TABLE IF NOT EXISTS invoices (
            payment_hash TEXT PRIMARY KEY,
            amount INTEGER NOT NULL,
            need_id INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `, (err) => {
        if (err) console.error("Chyba při vytváření tabulky 'invoices':", err.message);
    });
});

module.exports = db;
